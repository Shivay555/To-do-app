insert into To_Do (ID, USERNAME, DESCRIPTION, TARGET_DATE, DONE)
values(10001, 'shivay', 'Get AWs certified',CURRENT_DATE(), false);

insert into To_Do (ID, USERNAME, DESCRIPTION, TARGET_DATE, DONE)
values(10002, 'shivay', 'Programming Daily',CURRENT_DATE(), false);

insert into To_Do (ID, USERNAME, DESCRIPTION, TARGET_DATE, DONE)
values(10003, 'shivay', 'Get AZURE certified',CURRENT_DATE(), false);

insert into To_Do (ID, USERNAME, DESCRIPTION, TARGET_DATE, DONE)
values(10004, 'shivay', 'LEARN React certified',CURRENT_DATE(), false);