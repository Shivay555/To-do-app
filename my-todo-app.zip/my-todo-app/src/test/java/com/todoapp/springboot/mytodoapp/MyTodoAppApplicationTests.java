package com.todoapp.springboot.mytodoapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyTodoAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
